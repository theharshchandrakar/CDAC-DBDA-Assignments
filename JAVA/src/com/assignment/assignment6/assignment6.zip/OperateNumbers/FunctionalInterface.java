package com.assignment.assignment6.OperateNumbers;

public @interface FunctionalInterface {

}
