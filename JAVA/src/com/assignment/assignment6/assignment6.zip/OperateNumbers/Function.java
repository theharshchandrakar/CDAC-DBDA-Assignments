package com.assignment.assignment6.OperateNumbers;

@FunctionalInterface
public interface Function {
	int apply(int n);
}
