package com.assignment.assignment3;

public interface Rentable {
	double rent(int hrs);
}
