inp = str(input("Enter a string"))
up = inp.isupper()
if up:
    print("All letters are uppercase.")
else:
    print("All letters are not uppercase.")